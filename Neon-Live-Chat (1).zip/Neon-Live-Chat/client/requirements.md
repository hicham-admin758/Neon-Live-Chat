## Packages
socket.io-client | Real-time communication for game circle updates

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  'segoe': ['"Segoe UI"', 'Tahoma', 'Geneva', 'Verdana', 'sans-serif'],
}
