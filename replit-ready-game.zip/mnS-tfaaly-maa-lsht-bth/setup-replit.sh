#!/bin/bash

# 🎮 سكربت تثبيت لعبة قنبلة الدردشة على Replit
# =====================================================

echo "🎮 ======================================"
echo "   تثبيت لعبة قنبلة الدردشة"
echo "   Replit Setup Script"
echo "========================================"
echo ""

# تنظيف المجلد
echo "🧹 تنظيف المجلد..."
rm -rf node_modules package-lock.json

# تثبيت المكتبات
echo "📦 تثبيت المكتبات..."
npm install

# إنشاء ملف .env إذا لم يكن موجود
if [ ! -f .env ]; then
    echo "📝 إنشاء ملف .env..."
    cat > .env << EOF
# YouTube API Configuration
YOUTUBE_API_KEY=your_youtube_api_key_here

# Database Configuration (Replit provides this automatically)
DATABASE_URL=\${DATABASE_URL}

# Server Configuration
PORT=5000
NODE_ENV=production
EOF
    echo "✅ تم إنشاء ملف .env - لا تنسى إضافة YouTube API Key!"
fi

# بناء المشروع
echo "🔨 بناء المشروع..."
npm run build

echo ""
echo "✅ ======================================"
echo "   اكتمل التثبيت بنجاح!"
echo "========================================"
echo ""
echo "📋 الخطوات التالية:"
echo "1. أضف YouTube API Key في ملف .env"
echo "2. شغّل الأمر: npm start"
echo "3. افتح التطبيق في المتصفح"
echo ""
echo "🎮 استمتع باللعب!"
echo ""
