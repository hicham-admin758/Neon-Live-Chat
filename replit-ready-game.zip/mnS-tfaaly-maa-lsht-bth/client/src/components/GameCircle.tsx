import { useUsers } from "@/hooks/use-users";
import { Bomb, Trophy, Skull, Play, RotateCcw, Users, Zap, Crown } from "lucide-react";
import { useState, useEffect } from "react";
import { io } from "socket.io-client";
import { queryClient } from "@/lib/queryClient";
import { api } from "@shared/routes";
import { type User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

// روابط الأصوات المحسّنة
const SOUNDS = {
  tick: "https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3",
  explosion: "https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3",
  pass: "https://assets.mixkit.co/active_storage/sfx/2572/2572-preview.mp3",
  victory: "https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3"
};

export function GameCircle() {
  const { data: users, isLoading } = useUsers();
  const { toast } = useToast();
  const [bombPlayerId, setBombPlayerId] = useState<number | null>(null);
  const [winner, setWinner] = useState<User | null>(null);
  const [explodingId, setExplodingId] = useState<number | null>(null);

  // تشغيل الأصوات
  const playSound = (type: keyof typeof SOUNDS) => {
    try {
      const audio = new Audio(SOUNDS[type]);
      audio.volume = 0.6;
      audio.play().catch(e => console.log("Audio play failed", e));
    } catch (e) {
      console.error("Sound error", e);
    }
  };

  // التحكم في اللعبة
  const handleStartGame = async () => {
    try {
      const response = await api.post("/api/game/start-bomb");
      
      toast({ 
        title: "🎮 بدأت اللعبة!", 
        description: "القنبلة انطلقت الآن 💣",
        className: "bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0"
      });
      
      playSound("pass");
    } catch (e: any) {
      const errorMsg = e.response?.data?.message || "حدث خطأ ما";
      toast({ 
        title: "⚠️ لا يمكن بدء اللعبة", 
        description: errorMsg === "عدد اللاعبين غير كاف" 
          ? "يجب وجود لاعبين اثنين على الأقل للعب" 
          : errorMsg,
        variant: "destructive",
        className: "bg-red-600 text-white border-0"
      });
    }
  };

  const handleResetGame = async () => {
    try {
      await api.post("/api/game/reset");
      setWinner(null);
      setBombPlayerId(null);
      setExplodingId(null);
      toast({ 
        title: "✅ تمت إعادة التعيين", 
        description: "اللعبة جاهزة لجولة جديدة!",
        className: "bg-blue-600 text-white border-0"
      });
    } catch (e) {
      console.error(e);
      toast({
        title: "خطأ",
        description: "فشلت عملية إعادة التعيين",
        variant: "destructive"
      });
    }
  };

  useEffect(() => {
    const socket = io(window.location.origin, { path: "/socket.io" });

    socket.on("bomb_started", ({ playerId }) => {
      console.log(`💣 Bomb passed to: ${playerId}`);
      if (bombPlayerId !== playerId) {
        playSound("pass");
        setBombPlayerId(playerId);
        setWinner(null);
      }
    });

    socket.on("player_eliminated", ({ playerId }) => {
      console.log(`💥 Eliminated: ${playerId}`);
      playSound("explosion");
      setExplodingId(playerId);

      setBombPlayerId(prev => prev === playerId ? null : prev);

      setTimeout(() => {
        setExplodingId(null);
        queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      }, 1500);
    });

    socket.on("game_winner", (winnerUser: User) => {
      console.log(`🏆 Winner: ${winnerUser.username}`);
      playSound("victory");
      setWinner(winnerUser);
      setBombPlayerId(null);
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
    });

    socket.on("game_reset", () => {
      setWinner(null);
      setBombPlayerId(null);
      setExplodingId(null);
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
    });

    socket.on("new_player", () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
    });

    return () => {
      socket.disconnect();
    };
  }, [bombPlayerId]);

  // حساب نصف القطر
  const activePlayers = users?.filter(u => u.lobbyStatus === "active") || [];

  const getRadius = () => {
    const count = activePlayers.length;
    if (count <= 5) return 140;
    if (count <= 10) return 190;
    if (count <= 15) return 240;
    return 300;
  };

  const radius = getRadius();

  // === حالة التحميل ===
  if (isLoading) {
    return <div className="text-white text-center mt-20">جاري تحميل الساحة...</div>;
  }

  // === شاشة الفوز ===
  if (winner) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[70vh] animate-in zoom-in duration-700 relative">
        {/* خلفية متحركة */}
        <div className="absolute inset-0 overflow-hidden opacity-20">
          <div className="absolute w-96 h-96 bg-yellow-400 rounded-full blur-3xl animate-pulse top-10 left-1/4"></div>
          <div className="absolute w-96 h-96 bg-orange-400 rounded-full blur-3xl animate-pulse bottom-10 right-1/4"></div>
        </div>

        {/* محتوى الفوز */}
        <div className="relative z-10 flex flex-col items-center">
          <Crown size={80} className="text-yellow-400 mb-4 drop-shadow-[0_0_30px_rgba(250,204,21,0.8)] animate-bounce" />
          <Trophy size={140} className="text-yellow-400 mb-8 drop-shadow-[0_0_40px_rgba(250,204,21,0.6)] animate-pulse" />
          
          <div className="bg-gradient-to-r from-yellow-400 via-orange-500 to-yellow-400 p-1 rounded-2xl mb-6">
            <div className="bg-black/90 backdrop-blur-md px-8 py-4 rounded-2xl">
              <h2 className="text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-orange-400 to-yellow-300 text-center animate-pulse">
                {winner.username}
              </h2>
            </div>
          </div>

          <p className="text-4xl font-bold mb-4 bg-gradient-to-r from-yellow-300 to-orange-400 bg-clip-text text-transparent">
            🏆 بطل الساحة 🏆
          </p>
          
          <p className="text-xl text-white/70 mb-8 text-center max-w-md">
            تهانينا! لقد نجوت من القنبلة وفزت باللعبة
          </p>

          <div className="flex gap-4">
            <Button 
              onClick={handleResetGame} 
              size="lg" 
              className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-bold text-lg px-8 py-6 shadow-2xl hover:shadow-green-500/50 transition-all duration-300 border-2 border-white/20"
            >
              <Play className="ml-2 h-6 w-6" /> لعبة جديدة
            </Button>
          </div>
        </div>

        {/* نجوم متحركة */}
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute text-yellow-400 animate-ping"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${2 + Math.random() * 2}s`,
                opacity: 0.6
              }}
            >
              ⭐
            </div>
          ))}
        </div>
      </div>
    );
  }

  // === ساحة اللعب ===
  return (
    <div className="w-full flex flex-col items-center relative min-h-[85vh]">

      {/* 🎮 لوحة التحكم العلوية المحسّنة */}
      <div className="absolute -top-12 left-1/2 -translate-x-1/2 flex gap-3 z-50">
        <div className="bg-gradient-to-br from-gray-900 to-black backdrop-blur-xl p-3 rounded-2xl border-2 border-white/10 shadow-2xl flex gap-3 items-center">
          <Button 
            onClick={handleStartGame} 
            disabled={activePlayers.length < 2 || bombPlayerId !== null}
            className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-bold px-6 py-5 text-base shadow-lg hover:shadow-green-500/50 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed border-2 border-white/20"
          >
            <Play className="ml-2 h-5 w-5" /> ابدأ اللعبة
          </Button>

          <Button 
            onClick={handleResetGame} 
            className="bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-600 hover:to-rose-700 text-white font-bold px-6 py-5 text-base shadow-lg hover:shadow-red-500/50 transition-all duration-300 border-2 border-white/20"
          >
            <RotateCcw className="ml-2 h-5 w-5" /> إعادة تعيين
          </Button>

          <div className="flex items-center gap-3 px-5 py-2 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-xl border-2 border-white/30 shadow-lg">
            <Users size={20} className="text-white" />
            <span className="text-white font-black text-lg">{activePlayers.length}</span>
            <span className="text-white/80 text-sm font-semibold">لاعب</span>
          </div>
        </div>
      </div>

      {/* رسالة توضيحية */}
      {activePlayers.length < 2 && bombPlayerId === null && (
        <div className="absolute -top-28 left-1/2 -translate-x-1/2 z-40">
          <div className="bg-yellow-500/90 backdrop-blur-md text-black px-6 py-3 rounded-full font-bold text-sm shadow-lg border-2 border-yellow-300 animate-pulse">
            ⚠️ يجب وجود لاعبين على الأقل لبدء اللعبة
          </div>
        </div>
      )}

      {/* منطقة اللعب */}
      <div className="relative flex items-center justify-center py-24 mt-16">

        {/* حالة الانتظار إذا لم يوجد لاعبين */}
        {activePlayers.length === 0 && (
          <div className="absolute text-center z-10">
             <div className="animate-pulse mb-4">
               <Users size={80} className="text-white/30 mx-auto mb-4" />
             </div>
             <div className="text-white/60 text-2xl font-bold mb-2">بانتظار انضمام اللاعبين...</div>
             <p className="text-base text-white/40 mt-2 bg-white/5 px-6 py-3 rounded-lg backdrop-blur-sm">
               اكتب <span className="text-cyan-400 font-bold">"دخول"</span> في شات اليوتيوب للانضمام
             </p>
          </div>
        )}

        {/* الخلفية الدائرية المتحركة */}
        <div className="absolute">
          <div 
            className="absolute rounded-full border-4 border-dashed border-white/5 animate-[spin_60s_linear_infinite]"
            style={{ width: radius * 2.8, height: radius * 2.8 }}
          />
          <div 
            className="absolute rounded-full border-2 border-white/10 animate-[spin_40s_linear_infinite_reverse]"
            style={{ width: radius * 2.5, height: radius * 2.5, top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }}
          />
        </div>

        {/* حاوية اللاعبين */}
        <div 
          className="relative transition-all duration-1000 ease-out"
          style={{ width: radius * 2, height: radius * 2 }}
        >
          {activePlayers.map((user, index) => {
            const total = activePlayers.length;
            const angle = (index / total) * 2 * Math.PI - Math.PI / 2;
            const x = Math.cos(angle) * radius;
            const y = Math.sin(angle) * radius;

            const isHoldingBomb = bombPlayerId === user.id;
            const isExploding = explodingId === user.id;

            return (
              <div
                key={user.id}
                className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 transition-all duration-500
                  ${isExploding ? "scale-150 z-50" : "hover:scale-110 z-10"}
                `}
                style={{ 
                  transform: `translate(${x}px, ${y}px) translate(-50%, -50%)`,
                }}
              >
                <div className="flex flex-col items-center gap-3 relative">

                  {/* Avatar Circle مع تحسينات */}
                  <div className={`relative w-24 h-24 rounded-full border-4 shadow-2xl overflow-visible transition-all duration-300
                    ${isHoldingBomb 
                      ? "border-red-500 shadow-[0_0_50px_rgba(239,68,68,0.8)] animate-pulse scale-110" 
                      : "border-white/30 bg-gradient-to-br from-gray-800 to-black shadow-[0_0_20px_rgba(255,255,255,0.1)]"}
                  `}>
                     {/* Badge ID محسّن */}
                     <div className="absolute -top-6 left-1/2 -translate-x-1/2 z-50">
                        <span className={`font-black text-xl px-3 py-1 rounded-full shadow-[0_0_15px_rgba(34,211,238,0.9)] border-2 transition-all duration-300
                          ${isHoldingBomb 
                            ? "bg-red-500 text-white border-white animate-pulse" 
                            : "bg-gradient-to-r from-cyan-400 to-blue-500 text-black border-white/50"}`}>
                          #{user.id}
                        </span>
                     </div>

                    {/* الصورة الشخصية */}
                    <div className="w-full h-full rounded-full overflow-hidden">
                      {user.avatarUrl ? (
                        <img src={user.avatarUrl} alt={user.username} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-700 to-gray-900 text-white">
                           <span className="font-bold text-3xl">{user.username.charAt(0).toUpperCase()}</span>
                        </div>
                      )}
                    </div>

                    {/* القنبلة */}
                    {isHoldingBomb && (
                      <div className="absolute -top-10 -right-10 z-50 animate-bounce">
                        <div className="relative">
                          <Bomb size={56} className="text-red-500 fill-red-600 drop-shadow-2xl" />
                          <div className="absolute inset-0 bg-red-500/30 rounded-full blur-xl animate-ping"></div>
                        </div>
                      </div>
                    )}

                    {/* تأثير الانفجار */}
                    {isExploding && (
                      <div className="absolute inset-0 -m-12 flex items-center justify-center z-50 pointer-events-none">
                         <Skull size={100} className="text-white animate-ping absolute" />
                         <div className="w-48 h-48 bg-gradient-to-r from-orange-500 via-red-500 to-orange-500 rounded-full animate-ping opacity-80"></div>
                         <div className="w-40 h-40 bg-red-600 rounded-full animate-pulse absolute"></div>
                      </div>
                    )}

                    {/* تأثير التوهج للاعب الحامل للقنبلة */}
                    {isHoldingBomb && (
                      <div className="absolute inset-0 -m-2 rounded-full bg-red-500/20 animate-pulse"></div>
                    )}
                  </div>

                  {/* Name Tag محسّن */}
                  <div className={`backdrop-blur-xl px-4 py-2 rounded-xl border-2 max-w-[160px] transition-all duration-300 shadow-lg
                    ${isHoldingBomb 
                      ? "bg-red-500/90 border-red-300 shadow-red-500/50" 
                      : "bg-black/80 border-white/20 shadow-black/50"}`}>
                    <p className={`font-bold text-base truncate text-center
                      ${isHoldingBomb ? "text-white" : "text-white/90"}`}>
                      {user.username}
                    </p>
                  </div>

                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* حالة اللعبة النشطة */}
      {bombPlayerId && (
        <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50">
          <div className="bg-gradient-to-r from-red-500 via-orange-500 to-red-500 backdrop-blur-xl px-8 py-4 rounded-full border-2 border-white/30 shadow-2xl animate-pulse">
            <div className="flex items-center gap-3">
              <Zap className="text-white animate-spin" size={24} />
              <span className="text-white font-black text-lg">اللعبة جارية الآن!</span>
              <Bomb className="text-white animate-bounce" size={24} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
