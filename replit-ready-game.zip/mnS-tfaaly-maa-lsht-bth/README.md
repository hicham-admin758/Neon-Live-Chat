# 🎮 لعبة قنبلة الدردشة - Chat Bomb Game

لعبة تفاعلية مع جمهور البث المباشر على YouTube

## 🚀 التشغيل السريع على Replit

### 1. رفع المشروع
```bash
# ارفع المجلد كاملاً إلى Replit
# أو استخدم "Import from GitHub"
```

### 2. إعداد Secrets
في Replit، اذهب إلى **Tools > Secrets** وأضف:
```
YOUTUBE_API_KEY = مفتاح_API_الخاص_بك
```

### 3. إضافة قاعدة البيانات
في Replit، اذهب إلى **Tools > Database**
سيتم إنشاء PostgreSQL تلقائياً

### 4. تشغيل المشروع
```bash
chmod +x setup-replit.sh
./setup-replit.sh
```

أو مباشرة:
```bash
npm install
npm run build
npm start
```

## 📋 المتطلبات

- Node.js 18+
- PostgreSQL
- YouTube API Key

## 🔑 الحصول على YouTube API Key

1. اذهب إلى [Google Cloud Console](https://console.cloud.google.com)
2. أنشئ مشروع جديد
3. فعّل YouTube Data API v3
4. أنشئ API Key من Credentials

## 🎮 كيفية اللعب

### للمشاهدين:
- اكتب `دخول` للانضمام
- اكتب `مرر لـ [رقم]` لتمرير القنبلة

### للمشرف:
1. ربط البث المباشر
2. انتظار انضمام لاعبين
3. الضغط على "ابدأ اللعبة"

## 📁 هيكل المشروع

```
├── client/          # Frontend (React + Vite)
├── server/          # Backend (Express + Socket.io)
├── shared/          # Shared types and schemas
├── .replit          # Replit configuration
├── replit.nix       # Nix dependencies
└── setup-replit.sh  # Setup script
```

## 🛠️ الأوامر المتاحة

```bash
npm run dev      # Development mode
npm run build    # Build project
npm start        # Production mode
npm run db:push  # Setup database
```

## 🐛 حل المشاكل

### "Cannot find module"
```bash
rm -rf node_modules
npm install
```

### "Port already in use"
غيّر البورت في `.env`:
```
PORT=5001
```

### "Database connection failed"
تحقق من `DATABASE_URL` في Secrets

## 📚 التوثيق الكامل

- [دليل إعداد Replit](./REPLIT_SETUP_GUIDE.md)
- [أوامر سريعة](./QUICK_COMMANDS.md)
- [شرح التحسينات](./IMPROVEMENTS.md)

## 🎨 التحسينات الجديدة

- ✅ إصلاح خطأ "يجب وجود لاعبين اثنين"
- ✅ تصميم محسّن مع تأثيرات متقدمة
- ✅ شاشة فوز احترافية
- ✅ تحسين الأداء والاستجابة
- ✅ رسائل خطأ واضحة ومفصلة

## 📞 الدعم

إذا واجهت مشكلة، تحقق من:
1. Console في المتصفح (F12)
2. Shell logs في Replit
3. أن YouTube API يعمل بشكل صحيح

## 📄 الترخيص

MIT License

---

صُنع بـ ❤️ مع Claude
